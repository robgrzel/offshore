//
// Created by robgrzel on 13.05.17.
//

#ifndef STABILITY_AND_DYNAMICS_OF_SHIP_AND_OFFSHORE_STRUCTURES_OWAVES_H
#define STABILITY_AND_DYNAMICS_OF_SHIP_AND_OFFSHORE_STRUCTURES_OWAVES_H


#define  GRAV 9.81
#define  PI 3.141592653589793238462643383279502884197169399375105820974944592307816406286L

#include <cstdio>
#include <cmath>
#include <iomanip>
#include <limits>


#include <vector>
#include <complex>
#include <valarray>
#include <algorithm>
#include <iostream>
#include "UtilSources/Math/math_utils.h"


typedef std::vector<long double> vecld_t;
typedef std::vector<double>      vecd_t;
typedef std::vector<long long>   vecll_t;
typedef std::vector<long>        vecl_t;
typedef std::vector<int>         veci_t;


typedef std::complex<double>   cdouble;
typedef std::valarray<cdouble> valcd_t;
typedef std::vector<cdouble>   veccd_t;

typedef std::complex<long double>   long_cdouble;
typedef std::valarray<long_cdouble> vallcd_t;
typedef std::vector<long_cdouble>   veclcd_t;

std::vector<int> slice( const std::vector<int>& v, int start = 0, int end = -1 ) {
	int oldlen = v.size();
	int newlen;

	if (end == -1 or end >= oldlen) {
		newlen = oldlen - start;
	} else {
		newlen = end - start;
	}

	std::vector<int> nv( newlen );

	for ( int i = 0; i < newlen; i++ ) {
		nv[i] = v[start + i];
	}
	return nv;
}

template <typename T>
std::vector<T> arange( T start, T stop, T step = 1 ) {

	std::vector<T> values;
	for ( T        value = start; value < stop; value += step ) {
		values.push_back( value );
	}

	return values;
}

void fftfreq( vecld_t& f, const long double d ) {

	const long long n = f.size();

	const long long N = (n - 1) / 2 + 1;

	long double val = 1. / (n * d);

	vecll_t p1( N );
	vecll_t p2( n / 2 );

	p1 = arange<long long>( 0, N );
	p2 = arange<long long>( -n / 2, 0 );

	for ( size_t i = 0, j = n - 1; i < N; i++, j-- ) {
		f[i] = p1[i];
		f[j] = p2[i];
	}

	for ( int i = 0; i < n; i++ ) {
		f[i] *= val;
	}


}

template <typename type>
size_t fftfreq_pos( type& f, const long double d ) {

	const size_t n = f.size();

	const size_t m = (n - 1) / 2 + 1;

	long double val = 1. / (n * d);

	f.resize( m );

	vecll_t p1( m );
	vecll_t p2( n / 2 );

	p1 = arange<long long>( 0, m );
	p2 = arange<long long>( -int( n ) / 2, 0 );

	for ( int i = 0; i < m; i++ ) {
		f[i] = p1[i];
	}

	for ( int i = 0; i < m; i++ ) {
		f[i] *= val;
	}

	return m;

}


void fft( veclcd_t& OUT, const vecd_t& IN, const bool& doNorm = false ) {
	// DFT

	size_t N = IN.size();

	size_t k            = N;
	size_t n, b;

	long_cdouble t;
	long_cdouble T;
	long_cdouble phiT;
	long double  thetaT = PI / N;

	phiT = long_cdouble( cos( thetaT ), -sin( thetaT ) );

	vallcd_t X( IN.size() );

	for ( size_t i = 0; i < N; i++ ) {
		X[i] = IN[i];
	}

	while ( k > 1 ) {
		n = k;
		k >>= 1;

		phiT = phiT * phiT;
		T    = 1.0L;

		for ( size_t l = 0; l < k; l++ ) {
			for ( size_t a = l; a < N; a += n ) {
				b    = a + k;
				t    = X[a] - X[b];
				X[a] += X[b];
				X[b] = t * T;
			}

			T *= phiT;
		}
	}
	// Decimate
	size_t       m = ( size_t ) log2( N );
	for ( size_t a = 0; a < N; a++ ) {
		b = a;
		// Reverse bits
		b = (((b & 0Xaaaaaaaa) >> 1) | ((b & 0X55555555) << 1));
		b = (((b & 0Xcccccccc) >> 2) | ((b & 0X33333333) << 2));
		b = (((b & 0Xf0f0f0f0) >> 4) | ((b & 0X0f0f0f0f) << 4));
		b = (((b & 0Xff00ff00) >> 8) | ((b & 0X00ff00ff) << 8));
		b = ((b >> 16) | (b << 16)) >> (32 - m);
		if (b > a) {
			t = X[a];
			X[a] = X[b];
			X[b] = t;
		}
	}
	//// Normalize (This section make it not working correctly)
	if (doNorm) {
		long_cdouble norm = 1.0L / N;
		X *= norm;
	}


	OUT.assign( std::begin( X ), std::end( X ) );

}

void fft_pos( vecd_t& OUT, const vecd_t& IN, const size_t& Npos, const bool& doNorm = false ) {

	veclcd_t OUT_( OUT.size() );

	fft( OUT_, IN, doNorm );

	OUT_.resize( Npos );

	for ( size_t i = 0; i < Npos; i++ ) {
		OUT[i] = abs( OUT_[i] );
	}


}

double spc2amp( double dom, double spc ) {
	return sqrt( 0.5 * dom * spc );
}

double amp2spc( double dom, double amp ) {
	return 2 * pow( abs( amp ), 2 ) / dom;
}

void fft_wave_elevation_long_crested(
		const size_t numSteps, const long double dt,
		const vecd_t& Z, long double& domFFT,
		size_t numFreqEvenFFT, vecd_t& omFFT, vecd_t& spcFFT
) {

	size_t numFreqPosFFT;

	numFreqEvenFFT = size_t( numSteps / 2 ); //half of freqs num rounded back if odd

	numFreqPosFFT = fftfreq_pos( omFFT, dt ); //size of positive freqs

	for ( int i = 0; i < numFreqPosFFT; i++ ) {
		omFFT[i] *= 2L * PI;
	}

	domFFT = 0;
	for ( int i = 1; i < numFreqEvenFFT - 1; i++ ) {
		domFFT += omFFT[i] - omFFT[i - 1];
	}

	domFFT /= numFreqEvenFFT;

	if (numSteps % 2) {
		omFFT.resize( numFreqEvenFFT );
	}

	spcFFT.resize( numSteps );

	fft_pos( spcFFT, Z, numFreqPosFFT, true );

	for ( int i = 0; i < numFreqPosFFT; i++ ) {
		spcFFT[i] = amp2spc( domFFT, spcFFT[i] );
	}

}


int polyfit(
		const double* const X, //x
		const double* const Y, //y
		unsigned int n,
		unsigned int order,
		double* coefficients
) {
	// Declarations...
	// ----------------------------------
	enum {
		maxOrder = 11
	};

	double B[maxOrder + 1]                        = {0.0f};
	double P[((maxOrder + 1) * 2) + 1]            = {0.0f};
	double A[(maxOrder + 1) * 2 * (maxOrder + 1)] = {0.0f};

	double x, y, powx;

	unsigned int ii, jj, kk;

	// Verify initial conditions....
	// ----------------------------------

	// This method requires that the n >
	// (order+1)
	if (n <= order) {
		return -1;
	}

	// This method has imposed an arbitrary bound of
	// order <= maxOrder.  Increase maxOrder if necessary.
	if (order > maxOrder) {
		return -1;
	}

	// Begin Code...
	// ----------------------------------

	// Identify the column vector
	for ( ii = 0; ii < n; ii++ ) {
		x    = X[ii];
		y    = Y[ii];
		powx = 1;

		for ( jj = 0; jj < (order + 1); jj++ ) {
			B[jj] = B[jj] + (y * powx);
			powx = powx * x;
		}
	}

	// Initialize the PowX array
	P[0] = n;

	// Compute the sum of the Powers of X
	for ( ii = 0; ii < n; ii++ ) {
		x    = X[ii];
		powx = X[ii];

		for ( jj = 1; jj < ((2 * (order + 1)) + 1); jj++ ) {
			P[jj] = P[jj] + powx;
			powx = powx * x;
		}
	}

	// Initialize the reduction matrix
	//
	for ( ii = 0; ii < (order + 1); ii++ ) {
		for ( jj = 0; jj < (order + 1); jj++ ) {
			A[(ii * (2 * (order + 1))) + jj] = P[ii + jj];
		}

		A[(ii * (2 * (order + 1))) + (ii + (order + 1))] = 1;
	}

	// Move the Identity matrix portion of the redux matrix
	// to the left side (find the inverse of the left side
	// of the redux matrix
	for ( ii = 0; ii < (order + 1); ii++ ) {
		x = A[(ii * (2 * (order + 1))) + ii];
		if (x != 0) {
			for ( kk = 0; kk < (2 * (order + 1)); kk++ ) {
				A[(ii * (2 * (order + 1))) + kk] =
						A[(ii * (2 * (order + 1))) + kk] / x;
			}

			for ( jj = 0; jj < (order + 1); jj++ ) {
				if ((jj - ii) != 0) {
					y        = A[(jj * (2 * (order + 1))) + ii];
					for ( kk = 0; kk < (2 * (order + 1)); kk++ ) {
						A[(jj * (2 * (order + 1))) + kk] =
								A[(jj * (2 * (order + 1))) + kk] -
								y * A[(ii * (2 * (order + 1))) + kk];
					}
				}
			}
		} else {
			// Cannot work with singular matrices
			return -1;
		}
	}

	// Calculate and Identify the coefficients
	for ( ii = 0; ii < (order + 1); ii++ ) {
		for ( jj = 0; jj < (order + 1); jj++ ) {
			x        = 0;
			for ( kk = 0; kk < (order + 1); kk++ ) {
				x = x + (A[(ii * (2 * (order + 1))) + (kk + (order + 1))] *
				         B[kk]);
			}
			coefficients[ii] = x;
		}
	}

	return 0;
}


int iround( double r ) {
	return (r > 0.0) ? (r + 0.5) : (r - 0.5);
}

double simps( const double& h, const vecd_t& y ) {

	const int  n   = int( y.size() );
	const bool odd = bool( n % 2 );
	double     sum = 0;

	if (n) {
		return .5 * h * (y.front() + y.back());
	} else {

		int m = n;
		if (odd) {
			sum = 3.0 / 8.0 * h * (y[n - 3] + 3.0 * (y[n - 2] + y[n - 1]) + y[n]);
			m   = n - 3;
		}

		if (m > 1) {
			double    sub = y.front();
			for ( int i   = 1; i < m - 2; i += 2 ) {
				sub += 4.0 * y[i] + 2.0 * y[i + 1];
			}
			sub += 4.0 * y[m - 1] + y[m];
			sum += h * sub / 3.0;
		}

		return sum;
	}
}


template <class T>
T min( std::vector<T> x ) {
	T min = *std::min_element( x.begin(), x.end() );
	return min;
}

template <class T>
T max( std::vector<T> x ) {
	T max = *std::max_element( x.begin(), x.end() );
	return max;
}


template <class T>
long arg_min( std::vector<T> x ) {
	long argMin = std::distance( x.begin(), std::min_element( x.begin(), x.end() ) );
	return argMin;
}


template <class T>
long arg_max( std::vector<T> x ) {
	long argMax = std::distance( x.begin(), std::max_element( x.begin(), x.end() ) );
	return argMax;
}


template <class T>
class std_vector_2d {
	private:
		std::vector<T> items_;
		size_t         width_;
		size_t         height_;

		const size_t idx( const size_t x, const size_t y ) const {
			return y * width_ + x;
		}

	public:
		size_t width( ) const {
			return width_;
		}

		size_t height( ) const {
			return height_;
		}

		T& operator ()( const size_t x, const size_t y ) {
			return items_[idx( x, y )];
		}

		T const& operator ()( const size_t x, const size_t y ) const {
			return items_[idx( x, y )];
		}

		size_t buffer_size( ) const {
			return width_ * height_;
		}

		T* buffer( ) {
			return &items_[0];
		}

		T const* buffer( ) const {
			return &items_[0];
		}

		std_vector_2d( size_t const w, size_t const h ) :
				items_( w * h ), width_( w ), height_( h ) {

		}
};


typedef struct AWavePuls_t {
	/*
	 * amp = sqrt(2*dom*S);
	 */

	double k;
	double om;
	double dom;
	double amp;
	double eps;
	double spc;


} AWavePuls;

typedef struct AWavePulsTime_t {

	/*
	 * theta = kx - om*t - eps;
	 * eta = amp * cos(theta);
	 */


	double theta;
	double eta;

} AWavePulsTime;

typedef struct AWaveTime_t {

	/*
	 * zeta += eta;
	 */

	double x;
	double t;
	double dt;
	double zeta;


} AWaveTime;


void wave_elevation_long_crested( const std::vector<AWavePuls_t>& O, std::vector<AWaveTime_t>& T, std_vector_2d<AWavePulsTime_t>& OT ) {

	AWavePuls_t     Oj;
	AWaveTime_t     Ti;
	AWavePulsTime_t OTij;

	const size_t N = O.size();
	const size_t M = T.size();

	double theta;
	double zeta;
	double eta;
	double eps;
	double amp;
	double om;
	double t;
	double k;
	double x;

	for ( size_t i = 0; i < M; i++ ) {
		Ti   = T[i];
		x    = Ti.x;
		t    = Ti.t;
		zeta = 0;
		for ( size_t j = 0; j < N; j++ ) {
			OTij = OT( i, j );

			Oj  = O[j];
			om  = Oj.om;
			amp = Oj.amp;
			eps = Oj.eps;
			k   = Oj.k;

			theta = k * x - om * t - eps;
			eta   = amp * cos( theta );
			zeta += eta;

			OTij.theta = theta;
			OTij.eta   = eta;

			OT( i, j ) = OTij;
		}

		T[i].zeta = zeta;
	}


}

void waves_phase_shift( std::vector<AWavePuls_t>& O ) {

	const size_t N = O.size();

	double EPS[N];

	standard_normal_2( N, EPS );

}

void spectra_amplitude( std::vector<AWavePuls_t>& O ) {

	double      dom;
	double      Spc;
	double      Amp;
	AWavePuls_t tmp;

	for ( int i = 0; i < O.size(); i++ ) {
		tmp = O[i];
		dom = tmp.dom;
		Spc = tmp.spc;
		Amp = sqrt( dom * 2 * Spc );
		O[i].amp = Amp;

	}
}

double pulsation_peak_mean( const std::vector<AWavePuls_t>& O ) {

	const size_t N = O.size();

	vecd_t spc( N );

	for ( int i = 0; i < N; i++ ) {

		spc[i] = O[i].spc;
	}

	long idSpcMax = arg_max( spc );
	std::cout << idSpcMax << std::endl;

	double omPeak = O[idSpcMax].om;

	return omPeak;


}


void spectra_moments( const int n, const int* ord, double* moments, const vecd_t& Spc, const vecd_t& Om, const double dom ) {
	//https://stackoverflow.com/questions/7627098/what-is-a-lambda-expression-in-c11

	const size_t N = Spc.size();

	vecd_t tmp( N );

	for ( int i = 0; i < n; i++ ) {

		for ( int j = 0; j < N; j++ ) {
			tmp[j] = Spc[i] * pow( Om[i], ord[i] );
		}

		moments[i] = simps( dom, tmp );
	}
}

void spectra_parameters( const std::vector<AWavePuls_t>& O, double H[4], double T[6], double M[7] ) {

	/*
	 moments [-1, 0, 1, 2, 3, 4, 5,]
	 heights [ 'RMS', 'mean: 1/2', 'significiant: 1/3', 'maximal: 1/10' ],
	 periods [ 'energy: -1(-10)', 'zerocrossing: 0(02)', 'mean: 1(01)',\
	           \'peak: T(S_max)', 'extrema: 2(24)', 'bandwi. e(20,40)', ]

	 */

	const int ord[7] = {-1, 0, 1, 2, 3, 4, 5};

	H[0] = 1;
	H[1] = 2.5;
	H[2] = 4.005;
	H[3] = 5.1;

	double dom = 0;

	const size_t N = O.size();


	vecd_t Spc( N );
	vecd_t Om( N );


	for ( int i = 0; i < N; i++ ) {
		Spc[i] = O[i].spc;
		Om[i]  = O[i].om;
		dom += O[i].dom;
	}

	dom /= N;

	spectra_moments( 7, ord, M, Spc, Om, dom );

	for ( int i = 0; i < 4; i++ ) {
		H[i] *= sqrt( M[1] );
	}

	T[0] = M[0] / M[1];
	T[1] = M[1] / M[3];
	T[2] = M[1] / M[2];
	T[3] = pulsation_peak_mean( O );
	T[4] = M[3] / M[5];
	T[5] = 1 - (pow( M[3], 2 ) / (M[1] * M[5]));

	for ( int i = 0; i < 5; i++ ) {
		T[i] *= 2 * M_PI;
	}

	T[1] = sqrt( T[1] );
	T[4] = sqrt( T[4] );
	T[5] = sqrt( T[5] );

}

int douglas_scale( double Hs ) {

	int s;

	if (Hs >= 0 and Hs < 0.1) {
		s = 0;
	} else if (Hs >= 0.1 and Hs < 0.5) {
		s = 1;
	} else if (Hs >= 0.5 and Hs < 1.25) {
		s = 2;
	} else if (Hs >= 1.25 and Hs < 2.5) {
		s = 4;
	} else if (Hs >= 2.5 and Hs < 4.) {
		s = 5;
	} else if (Hs >= 4. and Hs < 6.) {
		s = 6;
	} else if (Hs >= 6. and Hs < 9.) {
		s = 7;
	} else if (Hs >= 9. and Hs < 14.) {
		s = 8;
	} else if (Hs >= 14.) {
		s = 9;
	}

	return s;
}

typedef struct sea_scale_t {

	double fp;
	double velwind;
	double fetch_;
	double fetch;
	int    beaufort;
	int    douglass;

	sea_scale_t( const double Tp, const double Hs ) {

		fp = 1 / Tp;

		velwind = Tp * 0.87 * GRAV / (2 * M_PI * pow( 1.95, 1. / 7. ));

		fetch_ = pow( fp * velwind / GRAV, -3 );
		fetch  = fetch_ * pow( velwind, 2 ) / GRAV;

		beaufort = iround( pow( velwind / 0.836, 2. / 3. ) );

		douglass = douglas_scale( Hs );


	}

} sea_scale;


class OWavesJonswap {

	public:

		enum MRatioNarrow_t {
			standard  = 0,
			DNV       = 1,
			Brodtkorb = 2,
		};

		MRatioNarrow_t mrationarrow;

		long double Hs, Tp, fp, omp;
		long double dom, df, dt, tmax;
		long double domFFT;

		long double alpha, gamma;

		long double ommin = 2 * M_PI * 0.005;
		long double ommax = 2 * M_PI * 3.000;
		long double omrng = 2 * M_PI * 2.995;
		long double Tmin  = 1 / 3.000;
		long double Tmax  = 1 / 0.005;
		long double Trng  = 1 / 2.995;
		long double fmin  = 0.005;
		long double fmax  = 3.000;
		long double frng  = 2.995;
		long double fsamp = 50;

		const char* nameSeas = "seas";

		double H[4], H_FFT[4];
		double T[6], T_FFT[4];
		double M[7], M_FFT[4];

	private:

		const size_t numSteps;
		size_t       numWaves;
		size_t       numWavesFFT;

		std::vector<AWavePuls_t>       AWaveP_FFT;
		std::vector<AWavePuls_t>       AWaveP;
		std::vector<AWaveTime_t>       AWaveT;
		std_vector_2d<AWavePulsTime_t> AWavePT;

	protected:
		void init( ) {

			fp  = 1 / Tp;
			omp = 2 * M_PI * fp;

			dt  = 1 / fsamp;
			df  = 1 / tmax;
			dom = 2 * M_PI * df;

			sea_scale_t seaScale( Tp, Hs );

			std::vector<double> om = arange<double>( ommin, ommax, dom );
			std::vector<double> t  = arange<double>( 0, tmax, dt );

			for ( int i = 0; i < numWaves; i++ ) {
				AWaveP[i].dom = dom;
				AWaveP[i].om  = om[i];
			}
			for ( int i = 0; i < numSteps; i++ ) {
				AWaveT[i].dt = dt;
				AWaveT[i].t  = t[i];
			}


			ratio_narrowing();

			ratio_peakadnes();

			spectrum( alpha );

			pulsation_boundary( alpha, false );

			printf( "alpha=%Lf, gamma=%Lf", alpha, gamma );

			exit( 0 );

			spectra_parameters( AWaveP, H, T, M );

			wave_elevation_long_crested( AWaveP, AWaveT, AWavePT );

			vecd_t Z( numSteps );
			vecd_t omFFT;
			vecd_t spcFFT;

			for ( int i = 0; i < numSteps; i++ ) {
				Z[i] = AWaveT[i].zeta;
			}

			fft_wave_elevation_long_crested( numSteps, dt, Z, domFFT, numWavesFFT, omFFT, spcFFT );

			for ( int i = 0; i < numWavesFFT; i++ ) {
				AWaveP_FFT[i].spc = spcFFT[i];
				AWaveP_FFT[i].om  = omFFT[i];
				AWaveP_FFT[i].dom = domFFT;
				AWaveP_FFT[i].eps = 0;
				AWaveP_FFT[i].k   = 0;
				AWaveP_FFT[i].amp = 0;
			}

			spectra_parameters( AWaveP_FFT, H_FFT, T_FFT, M_FFT );


		}

		void ratio_narrowing_dnv( ) {
			double r = Tp / sqrt( Hs );
			if (r <= 3.5) {
				gamma = 5;
			} else if (3.6 < r < 5) {
				gamma = exp( 5.75 - (0.367 * Tp * sqrt( GRAV / Hs )) );
			} else if (5 <= r) {
				gamma = 1;
			}

			mrationarrow = DNV;
		}

		void ratio_narrowing_brodtkorb( ) {
			gamma = 0.1975L;
			gamma *= pow( Tp, 4L ) * pow( Hs, -2L );
			gamma *= 0.036L - (0.0056L * Tp / sqrt( Hs ));

			gamma = exp( 3.484L * (1L - gamma) );

			mrationarrow = Brodtkorb;
		}

		void ratio_narrowing_standard( ) {
			gamma = 3.3L;

			mrationarrow = standard;

		}

		bool check_ratio_narrowing( ) {

			long double r = Tp / sqrt( Hs );

			bool c = (gamma > 7 or gamma < 1);

			switch ( mrationarrow ) {
				case (DNV) : {
					c |= (3.6 < r < 5);
					break;
				}
				case (Brodtkorb) : {
					c |= (3.6 > r > 5);
					break;
				}
			}

			return c;
		}

		void ratio_narrowing( ) {

			switch ( mrationarrow ) {
				case (standard) : {
					ratio_narrowing_standard();
					return;
				}
				case (DNV) : {
					ratio_narrowing_dnv();
					if (check_ratio_narrowing()) {
						ratio_narrowing_standard();
					}
					return;
				}
				case (Brodtkorb) : {
					ratio_narrowing_brodtkorb();
					if (check_ratio_narrowing()) {
						ratio_narrowing_dnv();
						if (check_ratio_narrowing()) {
							ratio_narrowing_standard();
						}
					}
					return;

				}

			}
		}

		void ratio_peakadnes( long double a = 1, long double HsM0 = 0, long double tol = 1e-6 ) {

			int idOmmin, idOmmax;

			long double err = 1;

			std::vector<double> spc( numWaves );

			while ( err > tol ) {


				spectrum( a );

				pulsation_boundary( a, idOmmin, idOmmax, false );
				printf( "err=%Lf, a=%Lf\n", err, a );

				spc.resize( numWaves );

				for ( int i = idOmmin; i < idOmmax; i++ ) {
					spc[i] = AWaveP[i].spc;
					printf("i=%d, om=%Lf, idOmmin=%d, idOmmax=%d, spc=%Lf\n",i,AWaveP[i].om,idOmmin,idOmmax,AWaveP[i].spc);
				}
				exit( 0 );

				HsM0 = 4 * sqrt( simps( dom, spc ) );

				a *= Hs / HsM0;

				err = abs( Hs - HsM0 );

			}

			alpha = a;
		}

		void spectrum( long double alpha ) {

			long double spc;
			long double tau;
			long double om;
			long double om_omp;

			const long double M = 5, N = 4, M_N = 5. / 4.;

			AWavePuls_t tmp;


			for ( int i = 0; i < numWaves; i++ ) {
				tmp    = AWaveP[i];
				om     = tmp.om;
				spc    = tmp.spc;
				tau    = om <= omp ? 0.07 : 0.09;
				om_omp = om / omp;

				spc = alpha * pow( Hs, 2 ) * pow( omp, 4 ) * pow( om, -5 );
				spc *= exp( -M_N * pow( om_omp, -N ) );
				spc *= pow( gamma, exp( -0.5 * pow( (om_omp - 1) / tau, 2 ) ) );

				AWaveP[i].spc = double( spc );
			}


		}

		void pulsation_boundary_fit( ) {
			//limit spectra broadness of pulsation

			const int n   = 20;
			const int ord = 10;

			double x[n];

			double y[n] = {5.1101, 4.4501, 4.100, 3.8700,
			               3.7000, 3.5700, 3.4600, 3.3700,
			               3.2900, 3.2200, 3.1600, 3.1050,
			               3.0550, 3.0100, 2.9650, 2.9300,
			               2.8950, 2.8600, 2.8300, 2.8000
			};

			for ( int i = 0 + 1; i < n + 1; i++ ) {
				x[i - 1] = i;
			}

			double poly[ord + 1] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

			polyfit( x, y, n, ord, poly );

			ommax = 0;

			for ( int i = 0; i < ord + 1; i++ ) {
				ommax += pow( gamma, i ) * poly[i];
			}

			ommax *= omp;

			ommin = omp * (0.58 + (0.05 * (gamma - 1.) / 19.));

		};


		void pulsation_boundary_range( std::vector<AWavePuls_t>& AWaveP, size_t& numWaves, long double& dom ) {

			int idOmmin = 0;
			int idOmmax = 0;

			for ( int i = 0; i < numWaves; i++ ) {

				if (!idOmmin) {
					idOmmin = (ommin - dom < AWaveP[i].om) ? i : 0;
				};

				if (!idOmmax) {
					idOmmax = (ommax + dom < AWaveP[i].om) ? i : 0;
				};


			}


			std::vector<AWavePuls_t> AWaveP_( AWaveP.begin() + idOmmin, AWaveP.begin() + idOmmax );

			AWaveP.swap( AWaveP_ );

			AWaveP_.clear();

			numWaves = AWaveP.size();

			dom = (ommax - ommin) / numWaves;

		}

		void pulsation_boundary( long double alpha, int & idOmmin,int & idOmmax, bool isFFT ) {

			pulsation_boundary_fit();


			if (!isFFT) {

				pulsation_boundary_range( AWaveP, numWaves, dom );

				spectrum( alpha );


			} else {

				pulsation_boundary_range( AWaveP_FFT, numWavesFFT, domFFT );

			}

		}


	public:
		OWavesJonswap(
				const long double tmax, long double Hs, long double Tp,
				long double fsamp = 50, const char* nameSeas = "seas",
				MRatioNarrow_t mrationarrow = Brodtkorb
		) :

				tmax( tmax ),
				fsamp( fsamp ),
				Hs( Hs ), Tp( Tp ),

				numSteps( tmax * fsamp ),
				numWaves( frng * tmax ),

				AWaveT( tmax * fsamp ),
				AWaveP( frng * tmax ),
				AWavePT( frng * tmax, tmax * fsamp ),
				AWaveP_FFT( tmax * fsamp ),

				nameSeas( nameSeas ),
				mrationarrow( mrationarrow ) {
			init();
		};


};


#endif //STABILITY_AND_DYNAMICS_OF_SHIP_AND_OFFSHORE_STRUCTURES_OWAVES_H
