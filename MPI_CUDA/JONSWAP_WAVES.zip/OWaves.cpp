//
// Created by robgrzel on 13.05.17.
//

#include "OWaves.h"


int main(){

	OWavesJonswap(100,5,10,50,"seas",OWavesJonswap::Brodtkorb);

	return 0;
}
