#ifndef INTERNALS_RENDER_INIT_H_
#define INTERNALS_RENDER_INIT_H_

extern void render_init();
extern void render_init_rebind();
extern void render_init_free();

#endif /* INTERNALS_RENDER_INIT_H_ */
