// **********************************************************
// File:	glTemplate.cpp - 31/05/2005
// Desc:	file description
//
// Informacje na temat kompilacji znajduja sie w pliku readme.txt
// dostarczonym wraz z projektem
//
// Copyright (c) 2004 by Domino. All rights reserved.
// **********************************************************

#include <windows.h>
#include <GL\gl.h>
#include <cassert>
#include "../../Common/Utils.h"

// ****************************************************************************

#pragma comment(lib, "opengl32.lib")

// ****************************************************************************

HWND  g_hWnd = NULL;
HGLRC	hRC;
HDC   hDC;

// ****************************************************************************

int WINAPI DllMain( HINSTANCE hInstance, DWORD nReason, PVOID pReserved )
{
	return TRUE;
}

// ****************************************************************************

void SetDCPixelFormat(HDC hDC);

// ****************************************************************************

DLL_EXPORT bool Initialize(HWND hWnd)
{
  g_hWnd = hWnd;
  hDC = GetDC(hWnd);
  SetDCPixelFormat( hDC );
	hRC = wglCreateContext( hDC );
	wglMakeCurrent( hDC, hRC );

  return true;
};

// ****************************************************************************

DLL_EXPORT void DeInitialize()
{
  wglMakeCurrent( NULL, NULL );
  wglDeleteContext( hRC );
  ReleaseDC(g_hWnd, hDC);
};

// ****************************************************************************

DLL_EXPORT void Render()
{
	glClearColor( 0.0f, 0.0f, 0.0f, 1.0f );
	glClear(GL_COLOR_BUFFER_BIT );
	glFlush();
	SwapBuffers( hDC );
}

// ****************************************************************************

DLL_EXPORT char* GetEffectShortName()
{
  return "Template";
};

// ****************************************************************************

DLL_EXPORT char* GetEffectCategory()
{
  return OPENGL;
};

// ****************************************************************************

DLL_EXPORT char* GetEffectFullName()
{
  return "OpenGL Tutorial 01 : Template";
};

// ****************************************************************************

void SetDCPixelFormat( HDC hDC )
{
	INT	nPixelFormat;

	static PIXELFORMATDESCRIPTOR pfd = 
	{
		sizeof(PIXELFORMATDESCRIPTOR),
		1,
		PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL |
		PFD_DOUBLEBUFFER | PFD_TYPE_RGBA,
		8,
		0, 0, 0, 0, 0, 0,
		0, 0,
		0, 0, 0, 0, 0,
		16,
		0,
		0,
		PFD_MAIN_PLANE,
		0,
		0, 0, 0
	};
	nPixelFormat = ChoosePixelFormat(hDC, &pfd);
	SetPixelFormat(hDC, nPixelFormat, &pfd);
}

// ****************************************************************************