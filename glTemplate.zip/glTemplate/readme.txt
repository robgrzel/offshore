Aby skompilowac zrodla nalezy dodatkowo sciagnac plik common.zip i po rozpakowaniu umiescic katalog Common
na tym samym poziomie co katalog z projektem. Czyli:

..
<Common>
<Katalog_projektu>

Zrodla kompiluja sie do plikow dll, bedacych pluginami dla naszej przegladarki efektow. Po zbudowaniu projektu 
nalezy plik dll przegrac do katalogu 'effects' znajdujacego sie na tym samym poziomie co plik wykonywalny browsera.
Wszystkie niezbedne media (tekstury, shadery, siatki, itd) dostarczone z plikami projektu (znajduja sie w katalogu
'media' :) nalezy przegrac do katalogu 'media' znajdujacego sie rowniez na tym samym poziomie co katalog 'effects'.
Czyli powinno to wygladac tak:

..
<effects>
<media>
browser.exe

Aby zobaczyc dzialanie danego przykladu nalezy uruchomic browser i z menu po lewej wybrac interesujacy nas przyklad.